
import { useState } from 'react';
import QRCode from 'qrcode.react';

function App() {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [generatedUrl, setGeneratedUrl] = useState('');

  const handleGenerate = () => {
    const baseURL = 'https://yourdomain.com/pay';
    const params = new URLSearchParams({ name, amount });
    setGeneratedUrl(`${baseURL}?${params.toString()}`);
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', padding: 16 }}>
      <h1>Создание платежной ссылки</h1>
      <input
        type="text"
        placeholder="Имя"
        value={name}
        onChange={(e) => setName(e.target.value)}
        style={{ display: 'block', marginBottom: 8, width: '100%' }}
      />
      <input
        type="number"
        placeholder="Сумма"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        style={{ display: 'block', marginBottom: 8, width: '100%' }}
      />
      <button onClick={handleGenerate} style={{ display: 'block', width: '100%' }}>
        Сгенерировать
      </button>

      {generatedUrl && (
        <div style={{ textAlign: 'center', marginTop: 20 }}>
          <p>
            <a href={generatedUrl} target="_blank" rel="noreferrer">
              {generatedUrl}
            </a>
          </p>
          <QRCode value={generatedUrl} size={256} />
        </div>
      )}
    </div>
  );
}

export default App;
